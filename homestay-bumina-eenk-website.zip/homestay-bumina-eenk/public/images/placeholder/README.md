Placeholder images will be replaced with actual images
